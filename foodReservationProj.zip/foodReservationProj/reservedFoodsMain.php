<?php
    require_once 'classes/reservedFoodsView.class.php';

    $reservedFoodsView = new ReservedFoodsView();
    $reservedFoodsView->setReservedFoodDisplay();
?>