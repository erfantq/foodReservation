<?php
require_once 'dbh.class.php';
class Doc extends Dbh {

    public const DOW = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
}